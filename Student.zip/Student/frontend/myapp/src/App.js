import React from "react";
import Student from "./Student";
function App() {
  return (
    <Student/>
  );
}

export default App;
